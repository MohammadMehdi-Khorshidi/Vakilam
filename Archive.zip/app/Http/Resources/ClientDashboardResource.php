<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ClientDashboardResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'draft_cases' => LegalRequestResource::collection(
                $this['draft_cases']
            ),

            'submitted_requests' => LegalRequestResource::collection(
                $this['submitted_requests'] ?? []
            ),

            'active_cases' => LegalMatterResource::collection(
                $this['active_cases']
            ),
        ];
    }
}